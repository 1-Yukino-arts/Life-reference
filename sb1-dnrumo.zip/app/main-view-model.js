import { Observable, Utils } from '@nativescript/core';
import { pickImage } from './utils/imageHandler';
import { StorageManager } from './utils/storageManager';

export function createViewModel() {
    const viewModel = new Observable();
    
    // Initialize properties
    viewModel.images = [];
    viewModel.isGridView = true;
    viewModel.isDarkTheme = true;
    viewModel.isLoading = false;
    
    // Load saved settings
    const settings = StorageManager.getSettings();
    if (settings) {
        viewModel.isDarkTheme = settings.isDarkTheme;
        viewModel.isGridView = settings.isGridView;
        viewModel.notifyPropertyChange('isDarkTheme', viewModel.isDarkTheme);
        viewModel.notifyPropertyChange('isGridView', viewModel.isGridView);
    }
    
    // Theme toggle with error handling
    viewModel.toggleTheme = () => {
        try {
            viewModel.isDarkTheme = !viewModel.isDarkTheme;
            viewModel.notifyPropertyChange('isDarkTheme', viewModel.isDarkTheme);
            StorageManager.saveSettings({ isDarkTheme: viewModel.isDarkTheme });
        } catch (error) {
            console.error('Error toggling theme:', error);
            Utils.alert('Error changing theme');
        }
    };
    
    // Image handling with loading state
    viewModel.onAddImage = async () => {
        try {
            viewModel.isLoading = true;
            viewModel.notifyPropertyChange('isLoading', true);
            
            const image = await pickImage();
            if (image) {
                viewModel.images.push({
                    path: image.path,
                    rotation: 0,
                    opacity: 1,
                    scale: 1,
                    width: image.width,
                    height: image.height
                });
                viewModel.notifyPropertyChange('images', viewModel.images);
                await StorageManager.saveLayout(viewModel.images);
            }
        } catch (error) {
            console.error('Error adding image:', error);
            Utils.alert('Error adding image');
        } finally {
            viewModel.isLoading = false;
            viewModel.notifyPropertyChange('isLoading', false);
        }
    };

    // View toggle with error handling
    viewModel.toggleGridView = () => {
        try {
            viewModel.isGridView = !viewModel.isGridView;
            viewModel.notifyPropertyChange('isGridView', viewModel.isGridView);
            StorageManager.saveSettings({ isGridView: viewModel.isGridView });
        } catch (error) {
            console.error('Error toggling view:', error);
            Utils.alert('Error changing view');
        }
    };

    // Image manipulation with bounds checking
    viewModel.onPan = (args) => {
        try {
            const image = args.object;
            const parent = image.parent;
            
            if (args.state === 1) { // BEGAN
                image.translateX = image.translateX || 0;
                image.translateY = image.translateY || 0;
            } else if (args.state === 2) { // CHANGED
                const newX = image.translateX + args.deltaX;
                const newY = image.translateY + args.deltaY;
                
                // Bound checking
                const maxX = parent.getMeasuredWidth() - image.getMeasuredWidth();
                const maxY = parent.getMeasuredHeight() - image.getMeasuredHeight();
                
                image.translateX = Math.max(-maxX, Math.min(maxX, newX));
                image.translateY = Math.max(-maxY, Math.min(maxY, newY));
            }
        } catch (error) {
            console.error('Error handling pan:', error);
        }
    };

    viewModel.onPinch = (args) => {
        try {
            const image = args.object;
            if (image) {
                const newScale = image.scale * args.scale;
                if (newScale >= 0.5 && newScale <= 3) {
                    image.scale = newScale;
                    image.notify({ object: image, eventName: 'scale', value: newScale });
                }
            }
        } catch (error) {
            console.error('Error handling pinch:', error);
        }
    };

    // Load saved images with error handling
    const loadSavedImages = async () => {
        try {
            const savedLayout = await StorageManager.getLayout();
            if (savedLayout) {
                viewModel.images = savedLayout;
                viewModel.notifyPropertyChange('images', viewModel.images);
            }
        } catch (error) {
            console.error('Error loading saved images:', error);
        }
    };
    
    loadSavedImages();

    return viewModel;
}