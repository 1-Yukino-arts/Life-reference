import { Application } from '@nativescript/core';
import { initializeImageHandler } from './utils/imageHandler';

// Initialize image handling utilities
(async () => {
    try {
        await initializeImageHandler();
        Application.run({ moduleName: 'app-root' });
    } catch (error) {
        console.error('Error initializing app:', error);
        Application.run({ moduleName: 'app-root' });
    }
})();