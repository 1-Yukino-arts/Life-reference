import { ImagePicker } from '@nativescript/imagepicker';
import { PermissionHandler } from './permissionHandler';
import { ImageSource, knownFolders, path } from '@nativescript/core';

export async function initializeImageHandler() {
    try {
        const hasPermissions = await PermissionHandler.requestAllPermissions();
        if (!hasPermissions) {
            throw new Error('Required permissions not granted');
        }
        
        // Create necessary folders
        PermissionHandler.createAppFolders();
        
        return true;
    } catch (error) {
        console.error('Error initializing image handler:', error);
        return false;
    }
}

export async function pickImage() {
    try {
        const hasStoragePermission = await PermissionHandler.ensureStoragePermissions();
        if (!hasStoragePermission) {
            throw new Error('Storage permission not granted');
        }

        const imagePicker = new ImagePicker();
        const authorized = await imagePicker.authorize();
        
        if (authorized) {
            const selection = await imagePicker.present();
            if (selection && selection.length > 0) {
                const selectedImage = selection[0];
                
                // Save image to app's folder
                const documents = knownFolders.documents();
                const imageFolderPath = path.join(documents.path, 'images');
                const fileName = `image_${Date.now()}.jpg`;
                const savedPath = path.join(imageFolderPath, fileName);
                
                const imageSource = await ImageSource.fromAsset(selectedImage);
                await imageSource.saveToFile(savedPath, 'jpg');
                
                return {
                    path: savedPath,
                    width: imageSource.width,
                    height: imageSource.height
                };
            }
        }
        return null;
    } catch (error) {
        console.error('Error picking image:', error);
        return null;
    }
}