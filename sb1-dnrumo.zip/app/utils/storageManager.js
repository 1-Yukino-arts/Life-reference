import { ApplicationSettings } from '@nativescript/core';

export class StorageManager {
    static saveLayout(layout) {
        ApplicationSettings.setString('savedLayout', JSON.stringify(layout));
    }

    static getLayout() {
        const savedLayout = ApplicationSettings.getString('savedLayout');
        return savedLayout ? JSON.parse(savedLayout) : null;
    }

    static saveSettings(settings) {
        const currentSettings = this.getSettings();
        const newSettings = { ...currentSettings, ...settings };
        ApplicationSettings.setString('appSettings', JSON.stringify(newSettings));
    }

    static getSettings() {
        const settings = ApplicationSettings.getString('appSettings');
        return settings ? JSON.parse(settings) : {
            isDarkTheme: true,
            isGridView: true,
            autoSave: true
        };
    }
}