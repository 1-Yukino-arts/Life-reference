import { Application, Folder, knownFolders, path } from '@nativescript/core';
import { request, requestPermissions } from '@nativescript/core/permissions';

export class PermissionHandler {
    static async requestAllPermissions() {
        try {
            if (Application.android) {
                const permissions = [
                    'android.permission.READ_EXTERNAL_STORAGE',
                    'android.permission.WRITE_EXTERNAL_STORAGE',
                    'android.permission.CAMERA'
                ];

                const results = await requestPermissions(permissions);
                return Object.values(results).every(result => result === 'authorized');
            }
            return true; // iOS handles permissions differently
        } catch (error) {
            console.error('Error requesting permissions:', error);
            return false;
        }
    }

    static async ensureStoragePermissions() {
        if (Application.android) {
            try {
                const result = await request('android.permission.WRITE_EXTERNAL_STORAGE');
                return result === 'authorized';
            } catch (error) {
                console.error('Error requesting storage permission:', error);
                return false;
            }
        }
        return true;
    }

    static createAppFolders() {
        try {
            const documents = knownFolders.documents();
            const imageFolderPath = path.join(documents.path, 'images');
            const imageFolder = Folder.fromPath(imageFolderPath);
            
            if (!Folder.exists(imageFolderPath)) {
                Folder.fromPath(imageFolderPath);
            }
            
            return imageFolderPath;
        } catch (error) {
            console.error('Error creating app folders:', error);
            return null;
        }
    }
}