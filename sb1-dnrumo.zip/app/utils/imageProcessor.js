import { ImageSource, knownFolders } from '@nativescript/core';
import { ImagePicker } from '@nativescript/imagepicker';

export class ImageProcessor {
    static async pickImage() {
        const context = imagepicker.create({
            mode: "single"
        });

        try {
            const selection = await context.present();
            return selection[0];
        } catch (e) {
            console.error('Error picking image:', e);
            return null;
        }
    }

    static async saveImage(imagePath) {
        try {
            const folder = knownFolders.documents();
            const fileName = `image_${Date.now()}.jpg`;
            const path = folder.path + '/' + fileName;
            
            const imageSource = await ImageSource.fromFile(imagePath);
            const saved = await imageSource.saveToFile(path, "jpg");
            
            return saved ? path : null;
        } catch (e) {
            console.error('Error saving image:', e);
            return null;
        }
    }
}